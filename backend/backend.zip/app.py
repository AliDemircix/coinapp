from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///coins.db'
CORS(app)

db = SQLAlchemy(app)


class Coin(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    price = db.Column(db.Float, nullable=False)

    def to_dict(self):
        return {'id': self.id, 'name': self.name, 'amount': self.amount, 'price': self.price}
# with app.app_context():
#     db.create_all()

@app.route('/coins', methods=['POST'])
def add_coin():
    data = request.json
    coin = Coin(name=data['name'], amount=data['amount'], price=data['price'])
    db.session.add(coin)
    db.session.commit()
    return jsonify(coin.to_dict())


@app.route('/coins', methods=['GET'])
def get_coins():
    coins = Coin.query.all()
    return jsonify([coin.to_dict() for coin in coins])

@app.route('/coins/<int:id>', methods=['DELETE'])
def delete_coin(id):
    coin = Coin.query.get(id)
    if coin is None:
        return jsonify({'message': 'Coin not found'}), 404
    else:
        db.session.delete(coin)
        db.session.commit()
        return jsonify({'message': 'Coin deleted'}), 200
    
@app.route('/coins/<int:id>/update', methods=['PUT'])
def update_coin(id):
    coin = Coin.query.get(id)
    if coin is None:
        return jsonify({'message': 'Coin not found'}), 404
    else:
        data = request.json
        if 'name' in data:
            coin.name = data['name']
        if 'amount' in data:
            coin.amount = data['amount']
        if 'price' in data:
            coin.price = data['price']
        db.session.commit()
        return jsonify(coin.to_dict())

if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
