export const Home = ()=> {
    return <>
    Home page
    </>
}