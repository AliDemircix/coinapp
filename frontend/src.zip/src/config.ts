
let config = {
    baseurl: "/"
};

export default config;