import React, { useEffect } from 'react';
import { BrowserRouter, Navigate, Outlet, Route, Routes } from 'react-router-dom';
import * as Paths from './Paths';

import AlertPopup from './components/AlertPopup';
import { Home } from './pages/Home';
import { AlertProvider } from './context/AlertContext';
import Coins from './pages/Coins';
import AdminPage from './pages/Admin';
import { AddCoin } from './pages/AddCoin';

function CheckAuth() {
  const isAuth = true;
  useEffect(function check() {
    if (!isAuth) {
      document.location.href = Paths.admin.path;
    }
  })
  return <>
    <Outlet />
  </>
}

function App() {

  return (
      <AlertProvider>
        <AlertPopup />
          <BrowserRouter>
            <Routes >
              <Route
                path={Paths.home.path}
                element={<Home />}
              />
              <Route
                path="/"
                element={<CheckAuth />}>
                <Route
                  path={Paths.admin.path}
                  element={<AdminPage />} >
                  <Route
                    path={Paths.coins.path}
                    element={<Coins />}
                  />
                    <Route
                    path={Paths.addCoin.path}
                    element={<AddCoin />}
                  />
                 
                </Route>
              </Route>
              <Route index element={<Navigate to={Paths.admin.path} />} />
            </Routes>
          </BrowserRouter>
      </AlertProvider>
  )
}

export default App;
